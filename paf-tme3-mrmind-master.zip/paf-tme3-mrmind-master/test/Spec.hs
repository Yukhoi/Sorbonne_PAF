import Test.Hspec
import MindEngineSpec as ME

main :: IO ()
main = hspec $ do
  ME.engineSpec

